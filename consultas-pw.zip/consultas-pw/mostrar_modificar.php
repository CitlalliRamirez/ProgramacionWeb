<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilos.css">
  	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
	<title>Modificar datos</title>
</head>
<body>
<?php
	require_once "config.php";
	$id = $_GET['id']; 

	$query = mysqli_query($enla,"SELECT * FROM personas WHERE id=$id");
	while($datos_persona = mysqli_fetch_array($query)){
		$nombre = $datos_persona['nombre'];
		$apellido = $datos_persona['apellido'];
		$edad = $datos_persona['edad'];
		$sexo = $datos_persona['sexo'];
		$direccion = $datos_persona['direccion'];

?>
<div class="container">
	<form method="post" action="modificar.php">
		<input type="hidden" name="id" value="<?=$id?>">
		<div class="row">	
			<div class="col-25">
				<label for="nombr">Nombre: </label>
			</div>
			<div class="col-75">
				<input type="text" name="nombr" id="nombr" value="<?=$nombre?>" required>	
			</div>
		</div>
		<div class="row">	
			<div class="col-25">
				<label for="apel">Apellido: </label>
			</div>
			<div class="col-75">
				<input type="text" name="apel" id="apel" value="<?=$apellido?>" required>	
			</div>
		</div>
		<div class="row">	
			<div class="col-25">
				<label for="ed">Edad: </label>
			</div>
			<div class="col-75">
				<input type="text" name="ed" id="ed" value="<?=$edad?>" required>	
			</div>
		</div>
		<div class="row">	
			<div class="col-25">
				<label for="sex">Sexo: </label>
			</div>
			<div class="col-75">
				<?php
				echo "<input type=\"radio\" id=\"sex\" name=\"sex\" value=\"0\"";
				if($sexo==0){
					echo "checked> Femenino";
				}else{
					echo "> Femenino";
				}

				echo "<input type=\"radio\" id=\"sex\" name=\"sex\" value=\"1\"";
				if($sexo==1){
					echo "checked> Masculino";
				}else{
					echo "> Masculino";
				}
				?>
			</div>
		</div>
		<div class="row">	
			<div class="col-25">
				<label for="dir">Dirección: </label>
			</div>
			<div class="col-75">
				<input type="text" name="dir" id="dir" value="<?=$direccion?>" required>
			</div>
		</div>
		  <div class="row">
    <input type="submit" value="Submit">
  </div>
	</form>
</div>
<?php
	}	
?>
</body>
</html>
