<?php
	require_once "config.php";
	
	$id = $_POST['id'];
	$nombre = $_POST['nombr'];
	$apellido = $_POST['apel'];
	$edad = $_POST['ed'];
	$sexo = $_POST['sex'];
	$direccion = $_POST['dir'];

	$actual = mysqli_query($enla, "UPDATE personas SET nombre='$nombre', apellido='$apellido', edad='$edad', sexo='$sexo', direccion='$direccion' WHERE id='$id'");
	header('Location: consulta.php');
?>