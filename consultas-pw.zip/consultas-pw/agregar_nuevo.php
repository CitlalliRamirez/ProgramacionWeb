<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilos.css">
  	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
	<title>Agregar datos</title>
</head>
<body>
<div class="container">
	<form method="post" action="agregar.php">
		<div class="row">	
			<div class="col-25">
				<label for="nombr">Nombre: </label>
			</div>
			<div class="col-75">
				<input type="text" name="nombr" id="nombr" required>	
			</div>
		</div>
		<div class="row">	
			<div class="col-25">
				<label for="apel">Apellido: </label>
			</div>
			<div class="col-75">
				<input type="text" name="apel" id="apel" required>	
			</div>
		</div>
		<div class="row">	
			<div class="col-25">
				<label for="ed">Edad: </label>
			</div>
			<div class="col-75">
				<input type="text" name="ed" id="ed" required>	
			</div>
		</div>
		<div class="row">	
			<div class="col-25">
				<label for="sex">Sexo: </label>
			</div>
			<div class="col-75">
				<input type="radio" id="sex" name="sex" value="0">Femenino
				<input type="radio" id="sex" name="sex" value="1">Masculino
			</div>
		</div>
		<div class="row">	
			<div class="col-25">
				<label for="dir">Dirección: </label>
			</div>
			<div class="col-75">
				<input type="text" name="dir" id="dir" required>
			</div>
		</div>
		  <div class="row">
    <input type="submit" value="Submit">
  </div>
	</form>
</div>
</body>
</html>
