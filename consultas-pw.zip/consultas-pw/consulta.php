<?php
require_once "config.php";
$query = "SELECT * FROM personas";
$res=mysqli_query($enla,$query) or die("Consulta fallida".mysql_error());
?>

<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilos.css">
  	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
	<title>Información</title>
</head>
<body>
	<table >
		<thead>
			<tr>
				<th>Nombre</th>
				<th>Apellido</th>
				<th>Edad</th>
				<th>Sexo</th>
				<th>Dirección</th>
				<th></th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<?php
				while($row = mysqli_fetch_array($res)){
				?>
				<tr>
					<td><?php echo utf8_encode($row['nombre']);?></td>
					<td><?php echo utf8_encode($row['apellido']);?></td>
					<td><?php echo $row['edad'];?></td>
					<td><?php if($row['sexo']==0){echo "Femenino";}else{ echo "Maculino";}?></td>
					<td><?php echo $row['direccion'];?></td>
					<td><a href="mostrar_modificar.php?id=<?php echo $row["id"]; ?>">modificar</a></td>
					<td><a href="eliminar.php?id=<?php echo $row["id"]; ?>">eliminar</a></td>
				</tr>
				<?php 
				}
				?>
		</tbody>
	</table>
	<br/><a type="button" href="index.php">Volver</a>

</body>
</html>
