<?php
require_once "config.php";
$id = $_GET['id'];

$query = mysqli_query($enla,"DELETE FROM personas WHERE id=$id");
echo "<script>alert('Se eliminó correctamente');</script>";
echo "<script>window.location='consulta.php';</script>";
//header('Location: consulta.php');
?>