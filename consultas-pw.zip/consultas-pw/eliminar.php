<?php
require_once "config.php";
$id = $_GET['id'];

$query = mysqli_query($enla,"DELETE FROM personas WHERE id=$id");
header('Location: consulta.php');
?>