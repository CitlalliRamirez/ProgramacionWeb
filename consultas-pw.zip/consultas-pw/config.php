<?php
$enla = mysqli_connect("localhost","root","root","datos_web");
/* comprueba la conexion */
if (mysqli_connect_errno()) {
    printf("Ha fallado la conexión: %s\n", mysqli_connect_error());
    exit();
}


?>