<?php 
require_once "config.php";
?>
<!DOCTYPE html>
<html lang="en-us">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilos.css">
  	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
	<title>Consultas</title>
</head>
<body>
<h2 align="center">Acciones</h2>
<table align="center">
	<tr>
		<td><ul>
	<li><a type="button" href="consulta.php">Consultar, modificar o eliminar persona</a> </li>
	<li><a type="button" href="agregar_nuevo.php">Agregar nueva persona</a></li>
</ul>
</td>
	</tr>
</table>


</body>
</html>
