<?php
	require_once "config.php";
	
	$nombre = $_POST['nombr'];
	$apellido = $_POST['apel'];
	$edad = $_POST['ed'];
	$sexo = $_POST['sex'];
	$direccion = $_POST['dir'];

	$nuevo = "INSERT INTO personas (nombre, apellido, edad, sexo, direccion) VALUES ('$nombre', '$apellido', '$edad', '$sexo', '$direccion');";
	$query = mysqli_query($enla, $nuevo);
	header('Location: index.php');
?>