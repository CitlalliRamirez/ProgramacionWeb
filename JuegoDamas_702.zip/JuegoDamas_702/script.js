window.onload = function() {    
//matriz para controlar los movimientos
  var MatrizJ = [ 
    [  0,  1,  0,  1,  0,  1,  0,  1 ],
    [  1,  0,  1,  0,  1,  0,  1,  0 ],
    [  0,  1,  0,  1,  0,  1,  0,  1 ],
    [  0,  0,  0,  0,  0,  0,  0,  0 ],
    [  0,  0,  0,  0,  0,  0,  0,  0 ],
    [  2,  0,  2,  0,  2,  0,  2,  0 ],
    [  0,  2,  0,  2,  0,  2,  0,  2 ],
    [  2,  0,  2,  0,  2,  0,  2,  0 ]
  ];
  var fichas = [];
  var cuadritos = []; 
  var cont = 0, cont2 = 0;

  function Ficha (elemento, posicion) {
    this.elemento = elemento;
    this.posicion = posicion; 
    this.jugador = '';
    if(this.elemento.attr("id") < 12)
      this.jugador = 1;
    else
      this.jugador = 2;
    this.FichaCoronada = false;
    this.Coronar = function () {
      this.elemento.css("backgroundImage","url('crown.png')");
      this.FichaCoronada = true;
    }
    this.move = function (tile) { 
      this.elemento.removeClass('selected'); 
      if(!Board.isValidPlacetoMove(tile.posicion[0], tile.posicion[1])) return false;
      if(this.jugador == 1 && this.FichaCoronada == false) {
        if(tile.posicion[0] < this.posicion[0]) return false;
      } else if (this.jugador == 2 && this.FichaCoronada == false) {
        if(tile.posicion[0] > this.posicion[0]) return false;
      }
      Board.contenedor[this.posicion[0]][this.posicion[1]] = 0;
      Board.contenedor[tile.posicion[0]][tile.posicion[1]] = this.jugador;
      this.posicion = [tile.posicion[0], tile.posicion[1]];
      this.elemento.css('top', Board.resoluciones[this.posicion[0]]);
      this.elemento.css('left', Board.resoluciones[this.posicion[1]]);
      if(!this.FichaCoronada && (this.posicion[0] == 0 || this.posicion[0] == 7 )) 
        this.Coronar();
      Board.changePlayerTurn();
      return true;
    };
    
    this.canJumpAny = function () {
      if(this.canOpponentJump([this.posicion[0]+2, this.posicion[1]+2]) ||
         this.canOpponentJump([this.posicion[0]+2, this.posicion[1]-2]) ||
         this.canOpponentJump([this.posicion[0]-2, this.posicion[1]+2]) ||
         this.canOpponentJump([this.posicion[0]-2, this.posicion[1]-2])) {
        return true;
      } return false;
    };
    
    this.canOpponentJump = function(newPosition) {
      var dx = newPosition[1] - this.posicion[1];
      var dy = newPosition[0] - this.posicion[0];
      if(this.jugador == 1 && this.FichaCoronada == false) {
        if(newPosition[0] < this.posicion[0]) return false;
      } else if (this.jugador == 2 && this.FichaCoronada == false) {
        if(newPosition[0] > this.posicion[0]) return false;
      }
      if(newPosition[0] > 7 || newPosition[1] > 7 || newPosition[0] < 0 || newPosition[1] < 0) return false;
      var tileToCheckx = this.posicion[1] + dx/2;
      var tileToChecky = this.posicion[0] + dy/2;
      if(!Board.isValidPlacetoMove(tileToChecky, tileToCheckx) && Board.isValidPlacetoMove(newPosition[0], newPosition[1])) {
        for(pieceIndex in fichas) {
          if(fichas[pieceIndex].posicion[0] == tileToChecky && fichas[pieceIndex].posicion[1] == tileToCheckx) {
            if(this.jugador != fichas[pieceIndex].jugador) {
              return fichas[pieceIndex];
            }
          }
        }
      }
      return false;
    };
    
    this.opponentJump = function (tile) {
      var pieceToRemove = this.canOpponentJump(tile.posicion);
      if(pieceToRemove) {
        fichas[pieceIndex].remove();
        return true;
      }
      return false;
    };
    
    this.remove = function () {
      this.elemento.css("display", "none");
      if(this.jugador == 1) {
        $('#player2').append("<div class='capturedPiece'></div>");
        cont++;
      }
      if(this.jugador == 2) {
        $('#player1').append("<div class='capturedPiece'></div>");
        cont2++;
      }
      

      Board.contenedor[this.posicion[0]][this.posicion[1]] = 0;
      this.posicion = [];
    }
  }
  
  //calcular la distancia
  var distancias = function (x1, y1, x2, y2) {
    return Math.sqrt(Math.pow((x1-x2),2)+Math.pow((y1-y2),2));
  }
  function Cuad (elemento, posicion) {
    // DOM elemento
    this.elemento = elemento;
    this.posicion = posicion;
    this.inRange = function(piece) {
      if(distancias(this.posicion[0], this.posicion[1], piece.posicion[0], piece.posicion[1]) == Math.sqrt(2)) {
        return 'regular';
      } else if(distancias(this.posicion[0], this.posicion[1], piece.posicion[0], piece.posicion[1]) == 2*Math.sqrt(2)) {
        return 'jump';
      }
    };
  }
  
  var Board = {
    contenedor: MatrizJ,
    playerTurn: 1,
    tilesElement: $('div.tablero'),
    resoluciones: ["0vmin", "10vmin", "20vmin", "30vmin", "40vmin", "50vmin", "60vmin", "70vmin", "80vmin", "90vmin"],
    initalize: function () {
      var countPieces = 0;
      var countTiles = 0;
      for (row in this.contenedor) { 
        for (column in this.contenedor[row]) {
          if(row%2 == 1) {
            if(column%2 == 0) {
              this.tilesElement.append("<div class='tile' id='tile"+countTiles+"' style='top:"+this.resoluciones[row]+";left:"+this.resoluciones[column]+";'></div>");
              cuadritos[countTiles] = new Cuad($("#tile"+countTiles), [parseInt(row), parseInt(column)]);
              countTiles += 1;
            }
          } else {
            if(column%2 == 1) {
              this.tilesElement.append("<div class='tile' id='tile"+countTiles+"' style='top:"+this.resoluciones[row]+";left:"+this.resoluciones[column]+";'></div>");
              cuadritos[countTiles] = new Cuad($("#tile"+countTiles), [parseInt(row), parseInt(column)]);
              countTiles += 1;
            }
          }
          if(this.contenedor[row][column] == 1) {
            $('.player1pieces').append("<div class='piece' id='"+countPieces+"' style='top:"+this.resoluciones[row]+";left:"+this.resoluciones[column]+";'></div>");
            fichas[countPieces] = new Ficha($("#"+countPieces), [parseInt(row), parseInt(column)]);
            countPieces += 1;
          } else if(this.contenedor[row][column] == 2) {
            $('.player2pieces').append("<div class='piece' id='"+countPieces+"' style='top:"+this.resoluciones[row]+";left:"+this.resoluciones[column]+";'></div>");
            fichas[countPieces] = new Ficha($("#"+countPieces), [parseInt(row), parseInt(column)]);
            countPieces += 1;
          }
        }
      }
    },
    isValidPlacetoMove: function (row, column) {
      console.log(row); console.log(column); console.log(this.contenedor);
      if(this.contenedor[row][column] == 0) {
        return true;
      } return false;
    },
    changePlayerTurn: function () {
      if(this.playerTurn == 1) {
        this.playerTurn = 2;
        $('.turn').css("background", "linear-gradient(to right, transparent 50%, #BEEE62 50%)");
        return;
      }
      if(this.playerTurn == 2) {
        this.playerTurn = 1;
        $('.turn').css("background", "linear-gradient(to right, #BEEE62 50%, transparent 50%)");
      }
      if(cont==12){
        alert("Felicidades ficha blanca has ganado");
        location.reload();
      }else if(cont2 == 12){
        alert("Felicidades ficha negra has ganado");
        location.reload();
      }

    },
    clear: function () {
      location.reload(); 
    }
  }
  
  Board.initalize();
  
  $('.piece').on("click", function () {
    var selected;
    var isPlayersTurn = ($(this).parent().attr("class").split(' ')[0] == "player"+Board.playerTurn+"pieces");
    if(isPlayersTurn) {
      if($(this).hasClass('selected')) selected = true;
      $('.piece').each(function(index) {$('.piece').eq(index).removeClass('selected')});
      if(!selected) {
        $(this).addClass('selected');
      }
    }
  });
  
  $('.tile').on("click", function () {
    if($('.selected').length != 0) {
      var tileID = $(this).attr("id").replace(/tile/, '');
      var tile = cuadritos[tileID];
      var piece = fichas[$('.selected').attr("id")];
      var inRange = tile.inRange(piece);
      if(inRange) {
        if(inRange == 'jump') {
          if(piece.opponentJump(tile)) {
            piece.move(tile);
            if(piece.canJumpAny()) {
               Board.changePlayerTurn();
               piece.elemento.addClass('selected');
            }
          } 
        } else if(inRange == 'regular') {
          if(!piece.canJumpAny()) {
            piece.move(tile);
          } else {
            alert("Hay una ficha que puedes comer. :)");
          }
        }
      }
    }
    
  });
  
}